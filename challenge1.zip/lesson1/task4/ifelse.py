bikes = 5
people = 7

if bikes == people:
    print
# Now you do the rest of the statements!
