# Numbers from 1 to 20
num_1_to_20 =

# Even numbers from 0 to 30
even_num_to_30 =

# Numbers from 99 down to 1
num_down_from_99 =

print num_1_to_20
print even_num_to_30
print num_down_from_99