# Calculating factorials using for loops

nine_factorial = 1  # What would happen if we initialised the variable inside the for loop?
for   in
    nine_factorial

print nine_factorial

