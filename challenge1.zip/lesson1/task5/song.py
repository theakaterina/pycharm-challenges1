# All the lyrics you'll need

lyric1 = "bottles of beer on the wall,"
lyric2 = "bottles of beer. You take one down, pass it around,"
lyric3 = "bottles of beer on the wall."
lyric4 = "bottle of beer on the wall."
lyric5 = "bottle of beer on the wall,"
lyric6 = "bottle of beer. You take it down, pass it around, go to the store and buy some more!"

# Code goes here

which loop goes here?
    How many different conditions do we need?