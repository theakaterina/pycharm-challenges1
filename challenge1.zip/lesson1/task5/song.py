# All the lyrics you'll need

lyric1 = "bottles of beer on the wall,"
lyric2 = "bottles of beer. You take one down, pass it around,"
lyric3 = "bottles of beer on the wall."
lyric4 = "bottle of beer on the wall."
lyric5 = "bottle of beer on the wall,"
lyric6 = "bottle of beer. You take it down, pass it around, go to the store and buy some more!"

# Code goes here

What do we want to loop over?
    if we print the same lyrics until which number?:
        print the lyrics and variables, seperated by commas
    elif what other condition do we look out for?:
        print more lyrics
    else:
        print the rest of the lyrics