from random import randint

answer = randint(1, 100)

# Boolean called not_correct. It should be True when the user is not right, and False when the user is right
not_correct =

# Remember, don't create an infinite loop.
while   :
    attempt = ask the user a question
    if    :
        print "You win!"
        not_correct = False
    elif
        print "Higher"
    else:
