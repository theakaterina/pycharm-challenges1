# Ask away!

variable = user input

variable = user input

variable = user input

print answers

