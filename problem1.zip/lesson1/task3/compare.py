# Make every answer equal to True (there is more than one correct way to do it!)

answer1 = "pie"    "pie"

answer2 = 5    80

answer3 = [1, 2, 3]    range(1, 4)

answer4 = [1, 2, 3]    range(1, 3)

answer5 = 5**3    36

answer6 = len(range(20))    20

print answer1, answer2, answer3, answer4, answer5, answer6