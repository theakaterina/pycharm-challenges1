# Calculating factorials using for loops

nine_factorial = 1  # What would happen if we initialised the variable inside the for loop?
for i in
    # What do we want to multiply nine_factorial by each time?
    nine_factorial = ? * ?

print nine_factorial

