bikes = 5
people = 7

if bikes == people:
    print
# Now you do the rest of the statements!
else if .....
    print whatever you want to say!
or else...
    print whatever you want to say!