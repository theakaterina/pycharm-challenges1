
score = 0
while score < 10:
    print "Your score is", score, "- keep trying."
    # write something here
print "Congrats, you win!"