# List of the odd numbers from 1 to 31
odd_integers = range(1, 32, 2)

odd_floats = [use a list comprehension]

print odd_floats
